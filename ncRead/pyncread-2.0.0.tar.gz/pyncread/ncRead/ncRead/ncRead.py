import curses
import locale
from curses import KEY_BACKSPACE, KEY_LEFT, KEY_RIGHT

locale.setlocale(locale.LC_ALL, '')

def listostr(l):
    if not isinstance(l,list): raise ValueError
    s = ""
    for i in l:
        s += i
    return s

def clrbox(win, y, x, minlim, vislim,color):
    win.attron(curses.color_pair(color))
    for i in range(x,x+(vislim-minlim)+1):
        win.addch(y,i,32)
    win.attroff(curses.color_pair(color))

def erase(win,string,p,sp,minlim,vislim,y,x,mode,color):
    string.pop(sp-1)
    clrbox(win,y,x,minlim,vislim,color)
    if not p and sp:
        vislim -= 1
        minlim -= 1
    acum1 = 0
    win.attron(curses.color_pair(color))
    for i in string[minlim:vislim+1]:
        if mode: win.addch(y,x+acum1,'*')
        else: win.addch(y,x+acum1,i)
        acum1 += 1
    win.attroff(curses.color_pair(color))
    if not (not p and sp): p -= 1
    sp -= 1
    return p,sp,minlim,vislim

def left(win,string,p,sp,minlim,vislim,y,x,mode,color):
    if not p and sp:
        vislim -= 1
        minlim -= 1
        clrbox(win,y,x,minlim,vislim,color)
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addch(y,x+acum1,i)
            acum1 += 1
        sp -= 1
        return p,sp,minlim,vislim
    p -= 1
    sp -= 1
    return p,sp,minlim,vislim

def right(win,string,p,sp,minlim,vislim,y,x,mode,color):
    if sp == vislim:
        vislim += 1
        minlim += 1
        clrbox(win,y,x,minlim,vislim,color)
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addch(y,x+acum1,i)
            acum1 += 1
        sp += 1
        return p,sp,minlim,vislim
    p += 1
    sp += 1
    return p,sp,minlim,vislim

def end(win,string,p,sp,minlim,vislim,ovislim,y,x,mode,color):
    cpyvslm = ovislim
    if len(string) > ovislim: vislim=len(string)
    if len(string) < ovislim: cpyvslm=len(string)
    minlim = len(string)-cpyvslm
    p = cpyvslm
    sp = len(string)
    clrbox(win,y,x,minlim,vislim,color)
    acum1 = 0
    win.attron(curses.color_pair(color))
    for i in string[minlim:vislim+1]:
        if mode: win.addch(y,x+acum1,'*')
        else: win.addch(y,x+acum1,i)
        acum1 += 1
    win.attroff(curses.color_pair(color))
    return p,sp,minlim,vislim

# Amplified sread()
def ampsread(win,y,x,vislim=30,chlim=30,mode=0,buffer="",color=0):
    curses.cbreak()
    curses.noecho()
    
    if type(buffer) != str: raise ValueError
    string = [i for i in buffer]
    p = 0  # Posición en el campo de escritura
    sp = 0  # Posición en el texto
    ovislim = vislim
    minlim = 0
    clrbox(win,y,x,minlim,vislim,color)
    if len(string):
        p,sp,minlim,vislim = end(win,string,p,sp,minlim,vislim,ovislim,y,x,mode,color)
    while True:
        ch = win.get_wch(y,x+p)
        if isinstance(ch, str):
            if ord(ch) == 127: ch = KEY_BACKSPACE
            elif ord(ch) == 8: ch = KEY_BACKSPACE
        if ch == chr(4):
            pass
        if ch == chr(27):
            return 0,listostr(string)
        if ch == chr(23):
            if not sp: continue
            #win.move(3,0);win.clrtoeol();win.addstr(3,0,str(sp))
            while sp and (string[sp-1] == ' '):
                p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode,color)
            while sp and (string[sp-1] != ' '):
                p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode,color)
            continue
        if ch == 548:  #^LEFT
            if not sp: continue
            while sp and (string[sp-1] == ' '):
                p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode,color)
            while sp and (string[sp-1] != ' '):
                p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode,color)
        if ch == 563:  #^RIGHT
            if sp == len(string): continue
            while (sp != len(string)-1) and (string[sp+1] != ' '):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode,color)
            while (sp != len(string)-1) and (string[sp+1] == ' '):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode,color)
            if sp != len(string):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode,color)
        if ch == 262:  # HOME
            p = 0
            sp = 0
            minlim = 0
            vislim = ovislim
            clrbox(win,y,x,minlim,vislim,color)
            acum1 = 0
            win.attron(curses.color_pair(color))
            for i in string[minlim:vislim+1]:
                if mode: win.addch(y,x+acum1,'*')
                else: win.addch(y,x+acum1,i)
                acum1 += 1
            win.attroff(curses.color_pair(color))
            continue
        if ch == 360:  # END
            p,sp,minlim,vislim = end(win,string,p,sp,minlim,vislim,ovislim,y,x,mode,color)
            continue
        if ch == '\n':
            return 1,listostr(string)
        if ch == KEY_BACKSPACE:
            if not sp: continue
            p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode,color)
            continue
        if ch == KEY_RIGHT:
            if sp == len(string): continue
            p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode,color)
        if ch == KEY_LEFT:
            if not sp: continue
            p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode,color)
        if len(string) == chlim: continue
        if isinstance(ch, int): continue
        string.insert(sp,ch)
        clrbox(win,y,x,minlim,vislim,color)
        if sp == vislim:
            vislim += 1
            minlim += 1
            acum1 = 0
            for i in string[minlim:vislim+1]:
                if mode: win.addch(y,x+acum1,'*')
                else: win.addstr(y,x+acum1,i,curses.color_pair(color))
                acum1 += 1
            sp += 1
            continue
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addstr(y,x+acum1,i,curses.color_pair(color))
            acum1 += 1
        sp += 1
        p += 1

# End

if __name__ == "__main__":
    def main(stdscr):
        curses.use_default_colors()
        curses.init_pair(1,0,15)
        stdscr.addstr(0,0,"Not editing")
        stdscr.addstr(1,0,"Input:")
        s = (0,"")
        while True:
            ch = stdscr.getch()
            if ch == ord('i'):
                stdscr.move(0,0);stdscr.clrtoeol()
                stdscr.addstr(0,0,"Editing")
                stdscr.refresh()
                s = ampsread(stdscr,1,7,10,50,0,s[1],1)
                stdscr.addstr(0,0,"Not editing")
                stdscr.refresh()
                if not s[0]: continue
                else: break
        curses.endwin()
    curses.wrapper(main)
