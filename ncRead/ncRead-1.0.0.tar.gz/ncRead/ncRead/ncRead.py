import curses
import locale
from curses import KEY_BACKSPACE, KEY_LEFT, KEY_RIGHT

locale.setlocale(locale.LC_ALL, '')

def listostr(l):
    if not isinstance(l,list): raise ValueError
    s = ""
    for i in l:
        s += i
    return s

def clrbox(win, y, x, minlim, vislim):
    win.attron(curses.color_pair(1))
    for i in range(x,x+(vislim-minlim)+1):
        win.addch(y,i,32)

def erase(win,string,p,sp,minlim,vislim,y,x,mode):
    string.pop(sp-1)
    clrbox(win,y,x,minlim,vislim)
    if not p and sp:
        vislim -= 1
        minlim -= 1
    acum1 = 0
    for i in string[minlim:vislim+1]:
        if mode: win.addch(y,x+acum1,'*')
        else: win.addch(y,x+acum1,i)
        acum1 += 1
    if not (not p and sp): p -= 1
    sp -= 1
    return p,sp,minlim,vislim

def left(win,string,p,sp,minlim,vislim,y,x,mode):
    if not p and sp:
        vislim -= 1
        minlim -= 1
        clrbox(win,y,x,minlim,vislim)
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addch(y,x+acum1,i)
            acum1 += 1
        sp -= 1
        return p,sp,minlim,vislim
    p -= 1
    sp -= 1
    return p,sp,minlim,vislim

def right(win,string,p,sp,minlim,vislim,y,x,mode):
    if sp == vislim:
        vislim += 1
        minlim += 1
        clrbox(win,y,x,minlim,vislim)
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addch(y,x+acum1,i)
            acum1 += 1
        sp += 1
        return p,sp,minlim,vislim
    p += 1
    sp += 1
    return p,sp,minlim,vislim

def end(win,string,p,sp,minlim,vislim,ovislim,y,x,mode):
    cpyvslm = ovislim
    if len(string) > ovislim: vislim=len(string)
    if len(string) < ovislim: cpyvslm=len(string)
    minlim = len(string)-cpyvslm
    p = cpyvslm
    sp = len(string)
    clrbox(win,y,x,minlim,vislim)
    acum1 = 0
    for i in string[minlim:vislim+1]:
        if mode: win.addch(y,x+acum1,'*')
        else: win.addch(y,x+acum1,i)
        acum1 += 1
    return p,sp,minlim,vislim

# Amplified sread()
def ampsread(win,y,x,vislim=30,chlim=30,mode=0,buffer=""):
    curses.cbreak()
    curses.noecho()

    string = [i for i in buffer]
    p = 0  # Posición en el campo de escritura
    sp = 0  # Posición en el texto
    ovislim = vislim
    minlim = 0
    clrbox(win,y,x,minlim,vislim)
    if len(string):
        p,sp,minlim,vislim = end(win,string,p,sp,minlim,vislim,ovislim,y,x,mode)
    while True:
        ch = win.get_wch(y,x+p)
        if isinstance(ch, str):
            if ord(ch) == 127: ch = KEY_BACKSPACE
            elif ord(ch) == 8: ch = KEY_BACKSPACE
        if ch == chr(4):
            pass
        if ch == chr(27):
            return None
        if ch == chr(23):
            if not sp: continue
            #win.move(3,0);win.clrtoeol();win.addstr(3,0,str(sp))
            while sp and (string[sp-1] == ' '):
                p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode)
            while sp and (string[sp-1] != ' '):
                p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode)
            continue
        if ch == 548:  #^LEFT
            if not sp: continue
            while sp and (string[sp-1] == ' '):
                p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode)
            while sp and (string[sp-1] != ' '):
                p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode)
        if ch == 563:  #^RIGHT
            if sp == len(string): continue
            while (sp != len(string)-1) and (string[sp+1] != ' '):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode)
            while (sp != len(string)-1) and (string[sp+1] == ' '):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode)
            if sp != len(string):
                p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode)
        if ch == 262:  # HOME
            p = 0
            sp = 0
            minlim = 0
            vislim = ovislim
            clrbox(win,y,x,minlim,vislim)
            acum1 = 0
            for i in string[minlim:vislim+1]:
                if mode: win.addch(y,x+acum1,'*')
                else: win.addch(y,x+acum1,i)
                acum1 += 1
            continue
        if ch == 360:  # END
            p,sp,minlim,vislim = end(win,string,p,sp,minlim,vislim,y,x,mode)
            continue
        if ch == '\n':
            return listostr(string)
        if ch == KEY_BACKSPACE:
            if not sp: continue
            p,sp,minlim,vislim = erase(win,string,p,sp,minlim,vislim,y,x,mode)
            continue
        if ch == KEY_RIGHT:
            if sp == len(string): continue
            p,sp,minlim,vislim = right(win,string,p,sp,minlim,vislim,y,x,mode)
        if ch == KEY_LEFT:
            if not sp: continue
            p,sp,minlim,vislim = left(win,string,p,sp,minlim,vislim,y,x,mode)
        if len(string) == chlim: continue
        if isinstance(ch, int): continue
        string.insert(sp,ch)
        clrbox(win,y,x,minlim,vislim)
        if sp == vislim:
            vislim += 1
            minlim += 1
            acum1 = 0
            for i in string[minlim:vislim+1]:
                if mode: win.addch(y,x+acum1,'*')
                else: win.addstr(y,x+acum1,i)
                acum1 += 1
            sp += 1
            continue
        acum1 = 0
        for i in string[minlim:vislim+1]:
            if mode: win.addch(y,x+acum1,'*')
            else: win.addstr(y,x+acum1,i)
            acum1 += 1
        sp += 1
        p += 1

# End

if __name__ == "__main__":
    def main(stdscr):
        curses.use_default_colors()
        curses.init_pair(1,0,15)
        stdscr.addstr(0,0,"Input:")
        stdscr.attron(curses.color_pair(1))
        s = ampsread(stdscr,0,7,10,50,0,"Hello world brah")
        stdscr.attroff(curses.color_pair(1))
        stdscr.addstr(2,0,f"String: {s}")
        stdscr.getch()
        curses.endwin()

    curses.wrapper(main)
