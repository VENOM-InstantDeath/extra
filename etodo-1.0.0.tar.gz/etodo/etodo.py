import curses
import json
from os import getenv, path, mkdir
from modules.ncRead import ampsread

def refresh(a,b=None):
    a.refresh()
    if b: b.refresh()

def reorder(t,a,b):
    s = t.pop(a)
    t.insert(b,s)

def display_opts(win,y,opts):
    x = 0
    caps=win.getmaxyx()
    keys = list(opts.keys())
    space = caps[1]//14
    if space > len(keys): space=len(keys)
    for i in range(space):
        win.addstr(y,x,keys[i],curses.color_pair(1))
        win.addstr(y,x+4,opts[keys[i]])
        x += 14

def lsref(win,data):
    win.move(0,0);win.clrtobot()
    for i in data:
        win.addstr(f"[{data[i]}] {i}")
        win.addstr('\n')
    tasks = tuple(data.keys())
    if tasks:
        win.move(0,4)
        win.addstr(tasks[0],curses.color_pair(1))
        win.move(0,0)
    refresh(win)

def line(win, y,x, mx):
    r = mx - x
    win.addstr(y,x,' '*r, curses.color_pair(1))
    refresh(win)

def addialog(mwin,y,x):
    curses.curs_set(1)
    win = curses.newwin(6,37, y//2-2, x//2-18)
    win.bkgd(' ', curses.color_pair(2))
    win.keypad(1)
    c = win.getmaxyx()
    line(win, 0,0,c[1])
    t = "Añadir tarea"
    win.addstr(0,c[1]//2-len(t)//2,t,curses.color_pair(1))
    win.addstr(2,3,"Tarea: ", curses.color_pair(3))
    win.addstr(4,c[1]//2-2,"[OK]",curses.color_pair(1))
    refresh(win,mwin)
    s = ampsread(win,2,10,c[1]-12,30)
    curses.curs_set(0)
    del win
    mwin.touchwin()
    refresh(mwin)
    return s

def main(stdscr):
    curses.curs_set(0)
    curses.use_default_colors()
    curses.init_pair(1,0,15)
    curses.init_pair(2,0,20)
    curses.init_pair(3,15,20)
    HOME = getenv("HOME")
    Path = f"{HOME}/.local/share/etodo"
    if not path.exists(f'{HOME}/.local'): mkdir(f"{HOME}/.local")
    if not path.exists(f'{HOME}/.local/share'): mkdir(f"{HOME}/.local/share")
    if not path.exists(Path): mkdir(Path)
    if not path.exists(f'{Path}/data.json'):
        dataf = open(f'{Path}/data.json', 'w+')
        dataf.write('{}')
        dataf.close()
    dataf = open(f"{Path}/data.json")
    data = json.load(dataf)
    dataf.close()
    y,x = stdscr.getmaxyx()
    line(stdscr,0,0,x)
    title = "Erika To-Do List"
    stdscr.addstr(0,x//2-len(title)//2,title,curses.color_pair(1))
    opts = {
            " a ":"Añadir",
            " d ":"Eliminar",
            " o ":"Subir",
            " l ":"Bajar",
            " q ":"Salir"
            }
    display_opts(stdscr,y-1,opts)
    wtask = curses.newwin(y-5,x-1, 2,0)
    wy,wx = wtask.getmaxyx()
    wtask.scrollok(1)
    for i in data:
        wtask.addstr(f"[{data[i]}] {i}")
        wtask.addstr('\n')
    p = 0  # pointer in tasks
    c = 0  # ncurses cursor
    tasks = tuple(data.keys())
    if tasks:
        wtask.move(0,4)
        wtask.addstr(tasks[0],curses.color_pair(1))
    refresh(stdscr,wtask)
    #start
    while True:
        k = str(stdscr.get_wch())
        if k == 'a':
            name = addialog(stdscr,wy,wx)
            refresh(stdscr,wtask)
            if not name:
                c = 0;p = 0
                lsref(wtask,data)
                continue
            data[name] = ' '
            dataf = open(f"{Path}/data.json",'w')
            dataf.write(json.dumps(data,indent=4))
            dataf.close()
            lsref(wtask,data)
            tasks = tuple(data.keys())
            c=0;p=0

        if k == 'o':
            if not p: continue
            keynvalue = [list(data.keys()),list(data.values())]
            reorder(keynvalue[0],p,p-1)
            reorder(keynvalue[1],p,p-1)
            data = {}
            for i in range(len(keynvalue[0])):
                data[keynvalue[0][i]] = keynvalue[1][i]
            dataf = open(f"{Path}/data.json",'w')
            dataf.write(json.dumps(data,indent=4))
            dataf.close()
            tasks = tuple(data.keys())
            p = 0; c = 0
            lsref(wtask,data)

        if k == 'l':
            if p == len(tasks): continue
            keynvalue = [list(data.keys()),list(data.values())]
            reorder(keynvalue[0],p,p+1)
            reorder(keynvalue[1],p,p+1)
            data = {}
            for i in range(len(keynvalue[0])):
                data[keynvalue[0][i]] = keynvalue[1][i]
            dataf = open(f"{Path}/data.json",'w')
            dataf.write(json.dumps(data,indent=4))
            dataf.close()
            tasks = tuple(data.keys())
            p = 0; c = 0
            lsref(wtask,data)

        if k == '258':
            if p == len(tasks)-1 or not tasks: continue
            wtask.move(c,4)
            wtask.addstr(tasks[p])
            p += 1;c += 1
            wtask.addstr(c,4,tasks[p],curses.color_pair(1))
            refresh(wtask)

        if k == '259':
            if p == 0: continue
            wtask.move(c,4)
            wtask.addstr(tasks[p])
            p -= 1;c -= 1
            wtask.addstr(c,4,tasks[p],curses.color_pair(1))
            refresh(wtask)

        if k == '\n':
            if not tasks: continue
            if data[tasks[p]] == ' ':
                data[tasks[p]] = 'x'
            else:
                data[tasks[p]] = ' '
            dataf = open(f"{Path}/data.json",'w')
            dataf.write(json.dumps(data,indent=4))
            dataf.close()
            lsref(wtask,data)
            p = 0; c = 0

        if k == 'd':
            if not tasks: continue
            data.pop(tasks[p])
            dataf = open(f"{Path}/data.json",'w')
            dataf.write(json.dumps(data,indent=4))
            dataf.close()
            lsref(wtask,data)
            tasks = tuple(data.keys())
            p = 0; c = 0

        if k == 'q':
            curses.endwin()
            exit(0)
    #end

if __name__=='__main__':
    curses.wrapper(main)
